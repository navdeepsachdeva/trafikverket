cisco_banner_definition = {
    "cisco_banner": {
        "default": None,
        "options": {
            "login_banner": {"default": None, "required": False, "type": "str"},
            "motd_banner": {"default": None, "required": False, "type": "str"},
        },
        "required": False,
        "type": "dict",
    }
}
