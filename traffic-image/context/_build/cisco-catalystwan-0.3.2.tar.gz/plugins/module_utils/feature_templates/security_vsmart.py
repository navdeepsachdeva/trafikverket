security_vsmart_definition = {
    "security_vsmart": {
        "default": None,
        "options": {
            "protocol": {"default": None, "required": False, "type": "str"},
            "tls_port": {"default": None, "required": False, "type": "int"},
        },
        "required": False,
        "type": "dict",
    }
}
